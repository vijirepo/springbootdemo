package org.cap.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class JavaConfig {
	
	@Bean(name="stud")
	//@Scope("prototype")
	public Student getStudentBean(){
		return new Student(123, "Tom", "Jerry");
	}
	
	@Bean(name="mark")
	public Marks getMarksBean(){
		return new Marks(90, 78);
	}
	
	@Bean(name="mymark")
	public Marks getMarksBean1(){
		return new Marks(34, 67);
	}

}
