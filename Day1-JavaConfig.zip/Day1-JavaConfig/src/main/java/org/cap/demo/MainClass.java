package org.cap.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(JavaConfig.class);
		
		Student student=(Student)context.getBean("stud");
		
		student.setStudid(1005);
		Student student2=(Student)context.getBean("stud");
		
		System.out.println(student);
		System.out.println(student2);
		
		//Student student2=new Student(1,"Jack","thomson");
	}

}
