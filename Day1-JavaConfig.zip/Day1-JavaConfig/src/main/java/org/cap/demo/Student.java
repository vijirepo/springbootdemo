package org.cap.demo;

import org.springframework.beans.factory.annotation.Autowired;

public class Student {
	
	private int studid;
	private String firstName;
	private String lastName;
	
	private Marks studMarks;
	
	public Student(){}
	
	public Student(int studid, String firstName, String lastName) {
		super();
		this.studid = studid;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	

	public Student(int studid, String firstName, String lastName, Marks studMarks) {
		super();
		this.studid = studid;
		this.firstName = firstName;
		this.lastName = lastName;
		this.studMarks = studMarks;
	}

	public int getStudid() {
		return studid;
	}

	public void setStudid(int studid) {
		this.studid = studid;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	
	
	
	public Marks getStudMarks() {
		return studMarks;
	}

	@Autowired
	public void setStudMarks(Marks studMarks) {
		this.studMarks = studMarks;
	}

	@Override
	public String toString() {
		return "Student [studid=" + studid + ", firstName=" + firstName + ", lastName=" + lastName + ", studMarks="
				+ studMarks + "]";
	}

	
	
	

}
