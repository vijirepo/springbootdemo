package org.cap.aop.demo;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class Logging {
	
	@Pointcut("execution (* org.cap.aop.demo.*.*(..))")
	public void myPointCut(){}
	
	@Before("myPointCut()")
	public void beforeAdvice(){
		System.out.println("Before Advice Method");
	}
	
	@After("myPointCut()")
	public void afterAdvice(){
		System.out.println("After Advice Method");
	}

	@AfterThrowing(value="myPointCut()",throwing="ex")
	public void afterthrowing(Exception ex){
		System.out.println("After Throwing Method:" + ex.getMessage());
		
	}
	
	@AfterReturning(value="myPointCut()",returning="val")
	public void afterReturning(Object val){
		System.out.println("After Returning Method:"+val.toString());
	}

}
