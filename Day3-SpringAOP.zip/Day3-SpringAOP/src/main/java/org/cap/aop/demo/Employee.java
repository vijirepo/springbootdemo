package org.cap.aop.demo;

public class Employee {
	
	private int empId;
	private String empName;
	
	public Employee(){}
	
	public Employee(int empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		System.out.println("Get Emp Name Method:");
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	public void throwException(){
		throw new IllegalArgumentException("Invalid Argument");
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + "]";
	}
	
	

}
