package org.cap.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day3WebInterfaceDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day3WebInterfaceDemoApplication.class, args);
	}
}
