package org.cap.controller;

import javax.validation.Valid;import org.apache.xerces.impl.xpath.regex.REUtil;
import org.cap.pojo.Employee;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
/*@RequestMapping("/employee")*/
public class HelloController {
	
	@RequestMapping("/hello")
	public ModelAndView sayHello(){
		String msg="Welcome To Spring MVC!";
		return new ModelAndView("helloPage","message",msg);
	}
	
	@RequestMapping("/employee")
	public ModelAndView showEmpForm(){
		return new ModelAndView("employeeForm","employee", new Employee());
	}

	
	@RequestMapping(value="/saveEmp",method=RequestMethod.POST)
	public String saveEmployee(@Valid @ModelAttribute("employee") Employee emp,
			BindingResult result){
		if(result.hasErrors())
			return "employeeForm";
		else{
		System.out.println(emp);
		return "empPage";
		}
	}
	
	
	
}
