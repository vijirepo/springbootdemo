package org.cap.controller;

import java.util.ArrayList;
import java.util.List;

import org.cap.pojo.Department;
import org.cap.pojo.Employee;
import org.cap.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;

	@RequestMapping("/empForm")
	public String showEmployeeForm(ModelMap map){
		
		map.put("employee", new Employee());
		map.put("departs", employeeService.getAllDepartments());
		map.put("employees", employeeService.getAllEmployees());
		return "employeeForm";
	}
	
	@RequestMapping(value="/saveEmployee",method=RequestMethod.POST)
	public String saveEmployeeDetails(@ModelAttribute("employee") Employee employee){
		
		employeeService.createEmployee(employee);
		return "redirect:empForm";
	}
	
	
	@RequestMapping("/deleteEmp/{empId}")
	public String deleteEmployee(@PathVariable("empId") Integer employeeId){
		employeeService.deleteEmployee(employeeId);
		return "redirect:/empForm";
	}
	
	
	
	
	
	
	
	
/*	
	public List<Department> getAllDepartment(){
		List<Department> departments=new ArrayList<>();
		departments.add(new Department(1,"Sales"));
		departments.add(new Department(2,"Finace"));
		departments.add(new Department(3,"HR"));
		departments.add(new Department(4,"Purchase"));
		
		return departments;
		
	}*/
	
}
