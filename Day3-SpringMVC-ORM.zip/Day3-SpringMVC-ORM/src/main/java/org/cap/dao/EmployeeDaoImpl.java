package org.cap.dao;

import java.util.List;

import org.cap.pojo.Department;
import org.cap.pojo.Employee;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDaoImpl implements EmployeeDao{
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void createEmployee(Employee employee) {
		sessionFactory.getCurrentSession().save(employee);
	}

	@Override
	public List<Department> getAllDepartments() {
		return sessionFactory.getCurrentSession().createQuery("from Department").list();
	}

	@Override
	public List<Employee> getAllEmployees() {
		
		return  sessionFactory.getCurrentSession().createQuery("from Employee").list();
	}

	@Override
	public void deleteEmployee(Integer empId) {
		
		Employee employee=(Employee)sessionFactory.getCurrentSession().get(Employee.class, empId);
		
		if(employee!=null)
			sessionFactory.getCurrentSession().delete(employee);
	}
	
	
}
