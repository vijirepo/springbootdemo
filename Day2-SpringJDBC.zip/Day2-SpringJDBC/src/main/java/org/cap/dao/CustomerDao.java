package org.cap.dao;

import java.util.List;

import org.cap.demo.Customer;

public interface CustomerDao {
	
	public void createCustomer(Customer customer);
	
	public void deleteCustomer(int customerId);
	
	public void countRecords();
	
	public String findCustomer(int customerId);
	
	public Customer getCustomer(int customerId);
	
	
	public List<Customer> getAllCustomer();
	
	public String searchCustomer(int custId);
	
}
