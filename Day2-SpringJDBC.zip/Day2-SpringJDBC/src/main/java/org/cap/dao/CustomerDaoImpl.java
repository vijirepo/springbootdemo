package org.cap.dao;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.cap.demo.Customer;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

public class CustomerDaoImpl implements CustomerDao{
	
	
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	private SimpleJdbcCall jdbcCall;
	
	
	

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplate=new JdbcTemplate(dataSource);
		this.jdbcCall=new SimpleJdbcCall(dataSource)
				.withProcedureName("searchCustomer");
				
	}


	public void createCustomer(Customer customer) {
		
		String sql="insert into customer, values(?,?,?)";
		jdbcTemplate.update(sql,customer.getCustomerId(),customer.getCustomerName(),customer.getEmailId());
		System.out.println("Customer Record inserted.");
	}


	public void deleteCustomer(int customerId) {
		String sql="delete from customer where customerid=?";
		jdbcTemplate.update(sql,customerId);
		System.out.println("Customer Record Deleted.");
	}


	public void countRecords() {
		String sql="select count(*) from customer";
		
		int count=jdbcTemplate.queryForInt(sql);
		
		System.out.println("Total records:" + count);
		
		
	}


	public String findCustomer(int customerId) {
		String sql="select customername from customer where customerid=?";
		String cname=jdbcTemplate.queryForObject(sql, new Object[]{customerId},String.class );
		
		return cname;
	}


	public Customer getCustomer(int customerId) {
		String sql="select * from customer where customerid=?";
		Customer customer=jdbcTemplate.queryForObject(sql, new Object[]{customerId}, new CustomerRowMapper());
		return customer;
	}


	public List<Customer> getAllCustomer() {
		String sql="select * from customer where customerid>?";
		int custId=1000;
		
		List<Customer> customers=jdbcTemplate.query(sql,new Object[]{custId}, new CustomerRowMapper());
		
		return customers;
	}


	public String searchCustomer(int custId) {
		MapSqlParameterSource sqlParameterSource=new MapSqlParameterSource().addValue("in_custId", custId);
		
		
		Map<String, Object> out_params= jdbcCall.execute(sqlParameterSource);
		
		String custName=(String)out_params.get("out_cname");
		
		
		return custName;
	}

}
 