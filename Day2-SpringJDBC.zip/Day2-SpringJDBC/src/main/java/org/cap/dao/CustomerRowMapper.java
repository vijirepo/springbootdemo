package org.cap.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.demo.Customer;
import org.springframework.jdbc.core.RowMapper;

public class CustomerRowMapper implements RowMapper<Customer>{

	public Customer mapRow(ResultSet rs, int count) throws SQLException {
		Customer customer=new Customer();
		
		customer.setCustomerId(rs.getInt(1));
		customer.setCustomerName(rs.getString(2));
		customer.setEmailId(rs.getString(3));
		
		return customer;
	}

}
