package org.cap.ui;

import java.util.List;

import org.cap.dao.CustomerDaoImpl;
import org.cap.demo.Customer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BootClass {

	public static void main(String[] args) {
	
		ApplicationContext context=new ClassPathXmlApplicationContext("jdbcBean.xml");
		
		CustomerDaoImpl custDao=(CustomerDaoImpl) context.getBean("jdbcTemp");
		
		/*Customer customer=new Customer(1235, "Jerry", "jerry@gmail.com");
		
		custDao.createCustomer(customer);
		*/
		//custDao.deleteCustomer(1001);
		
		//custDao.countRecords();
		
		/*String custName=custDao.findCustomer(123);
		
		System.out.println("CustomerName:" + custName);*/
		
		/*Customer customer=custDao.getCustomer(123);
		System.out.println("Customer :" + customer);*/
		
		
		
		/*List<Customer> customers=custDao.getAllCustomer();
		
		for(Customer customer:customers)
			System.out.println(customer);
		*/
		
		String custName=custDao.searchCustomer(123);
		System.out.println("CustomerName:" + custName);
	}

}
