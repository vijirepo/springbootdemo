package org.cap.demo;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;

public class Customer {

	private int custNo;
	private String firstName;
	private String lastName;
	private Address address;
	
	public Customer(){
		
		System.out.println("Customer Constructor Initilized");
	}
	//@Autowired
	public Customer(int custNo, String firstName, String lastName, Address address) {
		super();
		this.custNo = custNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
	}
	
	/*//@Autowired
	public Customer(String firstName, String lastName, Address address) {
		super();
		//this.custNo = custNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
	}
*/

	public int getCustNo() {
		return custNo;
	}

	//@Required
	public void setCustNo(int custNo) {
		this.custNo = custNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Address getAddress() {
		return address;
	}

	@Autowired
	@Qualifier("address1")
	public void setAddress(Address address) {
		this.address = address;
	}
	
	@PostConstruct
	public void init_Method(){
		System.out.println("Bean Initialized");
	}
	
	@PreDestroy
	public void destroy_Method(){
		System.out.println("Bean Destroyed.");
	}
	
	

	@Override
	public String toString() {
		return "Customer [custNo=" + custNo + ", firstName=" + firstName + ", lastName=" + lastName + ", address="
				+ address + "]";
	}
	
	
	
	
}
