package org.cap.demo;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class MainClass {

	public static void main(String[] args) {
		
		//ApplicationContext context=new ClassPathXmlApplicationContext("myBeans.xml");
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("myBeans.xml");
		
		//ApplicationContext context=new FileSystemXmlApplicationContext("D:\\vidavid\\Training\\2016\\Synchrony_Spring_15_Nov_to_18_Nov_2016\\myBeans.xml");
		
		//XmlBeanFactory context=new XmlBeanFactory(new ClassPathResource("myBeans.xml"));
		
		Customer customer=(Customer)context.getBean("customer");
		
		customer.setFirstName("Thomson");
		
		Customer customer2=(Customer)context.getBean("customer");
		
		System.out.println(customer);
		System.out.println(customer2);
		
		context.registerShutdownHook();
		
	}

}
