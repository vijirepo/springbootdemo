package org.cap.demo;

import java.util.List;

public class MyClass {
	
	private List<String> names;
	
	private List<Address> addresses;
	
	public MyClass(){}

	public MyClass(List<String> names) {
		super();
		this.names = names;
	}

	public List<String> getNames() {
		return names;
	}

	public void setNames(List<String> names) {
		this.names = names;
	}
	
	

	public List<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}

	@Override
	public String toString() {
		return "MyClass [names=" + names + "]";
	}
	
	
	

}
